﻿using UnityEngine.Events;

public class CountMessageEvent : UnityEvent<int>
{

}
